//! tokio FIX 4.2 echo contestant for the IICPC benchmark.
//!
//! Listens on 0.0.0.0:9898 (override with BIND or PORT), reads NewOrderSingle
//! (35=D) off each connection, and replies to every one with an ExecutionReport
//! (35=8, OrdStatus=New) echoing the order's ClOrdID (tag 11). That 35=8 reply is
//! what the eBPF latency capture classifies as a response and matches by ClOrdID.
//!
//! Higher-throughput than the std thread-per-conn fix-acker (tokio multi-thread +
//! batched per-read writes). FIX parsing + the ExecutionReport frame are inlined
//! (byte-for-byte the same wire format as bot-fleet/src/fix.rs) so this is a
//! self-contained submission with no local-crate dependency.
//!
//! THROUGHPUT contestant only: it acks without a real order book, so it will be
//! disqualified on correctness. A qualifying contestant needs a matching engine.

use std::env;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

const SOH: u8 = 0x01;

#[tokio::main(flavor = "multi_thread", worker_threads = 2)]
async fn main() -> std::io::Result<()> {
    let bind = env::var("BIND").unwrap_or_else(|_| {
        let port = env::var("PORT").unwrap_or_else(|_| "9898".to_string());
        format!("0.0.0.0:{port}")
    });
    let listener = TcpListener::bind(&bind).await?;
    eprintln!("fix_echo listening on {bind}");
    loop {
        let (stream, _peer) = listener.accept().await?;
        tokio::spawn(async move {
            if let Err(e) = handle(stream).await {
                eprintln!("connection error: {e}");
            }
        });
    }
}

async fn handle(mut stream: TcpStream) -> std::io::Result<()> {
    stream.set_nodelay(true).ok();
    let mut buf: Vec<u8> = Vec::with_capacity(16384);
    let mut chunk = [0u8; 8192];
    let mut out: Vec<u8> = Vec::with_capacity(16384);
    let mut seq: u64 = 1;

    loop {
        let n = stream.read(&mut chunk).await?;
        if n == 0 {
            return Ok(()); // peer closed
        }
        buf.extend_from_slice(&chunk[..n]);

        // Parse every complete FIX message currently in the buffer; for each
        // NewOrderSingle (35=D), append one ExecutionReport (35=8) to `out`.
        out.clear();
        let mut cursor = 0usize;
        loop {
            let Some(start_off) = find_subslice(&buf[cursor..], b"8=FIX") else {
                break;
            };
            let abs_start = cursor + start_off;
            let Some(end) = find_message_end(&buf[abs_start..]) else {
                break; // incomplete tail — wait for more bytes
            };
            let msg = &buf[abs_start..abs_start + end];
            if extract_tag(msg, b"35") == Some(b"D") {
                if let Some(clord) = extract_tag(msg, b"11") {
                    let clord = std::str::from_utf8(clord).unwrap_or("UNKNOWN");
                    append_execution_report(&mut out, seq, clord);
                    seq += 1;
                }
            }
            cursor = abs_start + end;
        }

        if !out.is_empty() {
            stream.write_all(&out).await?;
        }
        if cursor > 0 {
            buf.drain(..cursor);
        }
    }
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || needle.len() > haystack.len() {
        return None;
    }
    haystack.windows(needle.len()).position(|w| w == needle)
}

fn find_message_end(buf: &[u8]) -> Option<usize> {
    let needle = b"\x0110="; // checksum field terminates a FIX message
    let i = find_subslice(buf, needle)?;
    let after = i + needle.len();
    let soh = buf[after..].iter().position(|&b| b == SOH)?;
    Some(after + soh + 1)
}

fn extract_tag<'a>(msg: &'a [u8], tag: &[u8]) -> Option<&'a [u8]> {
    let mut needle = Vec::with_capacity(tag.len() + 2);
    needle.push(SOH);
    needle.extend_from_slice(tag);
    needle.push(b'=');
    let pos = find_subslice(msg, &needle)?;
    let vs = pos + needle.len();
    let ve = msg[vs..].iter().position(|&b| b == SOH)?;
    Some(&msg[vs..vs + ve])
}

fn append_execution_report(out: &mut Vec<u8>, seq: u64, clord_id: &str) {
    let body = format!(
        "35=8\x0149=CONTESTANT\x0156=IICPC-BOT\x0134={seq}\x0152=19700101-00:00:00.000\x0137=EXEC_{seq}\x0111={clord_id}\x0117=EXECID_{seq}\x01150=0\x0139=0\x0155=IICPC\x0154=1\x0138=0\x0114=0\x016=0\x01"
    );
    let mut frame = format!("8=FIX.4.2\x019={}\x01{body}", body.len()).into_bytes();
    let checksum = frame.iter().fold(0u32, |s, b| s.wrapping_add(u32::from(*b))) % 256;
    frame.extend_from_slice(format!("10={checksum:03}\x01").as_bytes());
    out.extend_from_slice(&frame);
}
